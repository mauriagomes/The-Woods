
document.addEventListener("DOMContentLoaded", function () {
    const backgroundElement = document.getElementById('background-container');
    const backgroundSelect = document.getElementById('background-select');

    backgroundSelect.addEventListener('change', function () {
        const selectedBackground = backgroundSelect.value;
        backgroundElement.style.backgroundImage = `url('${selectedBackground}')`;
    });
});


document.addEventListener("DOMContentLoaded", function() {
    const hiddenTexts = document.querySelectorAll(".hidden-text");

    hiddenTexts.forEach(hiddenText => {
        const text = hiddenText.nextElementSibling;

        hiddenText.addEventListener("click", function() {
            document.querySelectorAll('.hidden-text-content').forEach(function(el) {
                el.style.display = "none";
            });

           
            text.style.display = "block";

          
            hiddenText.parentElement.style.zIndex = 3;

            
            hiddenText.parentElement.classList.add('clicked');

            
            document.querySelectorAll('.image-container').forEach(function(el) {
                if (el !== hiddenText.parentElement) {
                    el.classList.remove('clicked');
                }
            });
        });

       
        text.addEventListener("mouseleave", function() {
            text.style.display = "block";
        });
    });
});

