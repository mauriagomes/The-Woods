document.addEventListener("DOMContentLoaded", function () {
  
    function getUrlParams() {
        const params = {};
        window.location.search.slice(1).split('&').forEach(param => {
            const [key, value] = param.split('=');
            params[key] = decodeURIComponent(value);
        });
        return params;
    }

    
    function updateVoteCount(character, count) {
    
        console.log(`Votes for ${character}: ${count}`);
    }

    const params = getUrlParams();
    const selectedPower = params.p;
    const character = params.c;

    if (selectedPower && character) {
    
        updateVoteCount(character, 1);
    }
});

