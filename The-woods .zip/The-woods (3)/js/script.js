document.addEventListener("DOMContentLoaded", function() {
 
    document.getElementById("home").classList.add("active");


    const links = document.querySelectorAll("nav a");
    links.forEach(link => {
        link.addEventListener("click", function(e) {
            e.preventDefault();
            const target = this.getAttribute("href").substring(1);
            const pages = document.querySelectorAll(".page");
            pages.forEach(page => {
                page.classList.remove("active");
            });
            document.getElementById(target).classList.add("active");
        });
    });

    
});
