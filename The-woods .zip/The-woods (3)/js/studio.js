
document.addEventListener("DOMContentLoaded", function () {
    const backgroundElement = document.getElementById('background-container');
    const backgroundSelect = document.getElementById('background-select');

    backgroundSelect.addEventListener('change', function () {
        const selectedBackground = backgroundSelect.value;
        backgroundElement.style.backgroundImage = `url('${selectedBackground}')`;
    });
});


document.addEventListener("DOMContentLoaded", function() {
    const powersContainer = document.getElementById("powers-container");
    const createAvatarBtn = document.getElementById("create-avatar-btn");
    const avatarPreview = document.getElementById("avatar-preview");

    function createAvatar() {
        const powers = {
            "Hemokinetic": "img/avatar1.png",
            "Magnetic Manipulation": "img/avatar2.png",
            "Telepathic": "img/avatar3.png",
            "Ability to alter size": "img/avatar4.png",
            "Invurnerability": "img/avatar5.png",
            "Strength and Durability": "img/avatar6.png",
            "Thermonuclear Aura": "img/avatar7.png"
        };
        const characterPowers = {
            "Hemokinetic": "img/marie.png",
            "Magnetic Manipulation": "img/andre.png",
            "Telepathic": "img/cate.png",
            "Ability to alter size": "img/emma.png",
            "Invurnerability": "img/jordan.png",
            "Strength and Durability": "img/sam.png",
            "Thermonuclear Aura": "img/luke.png"
        };



        const selectedPowers = [];

        powersContainer.querySelectorAll("input[type=checkbox]").forEach(checkbox => {
            if (checkbox.checked) {
                selectedPowers.push(checkbox.value);
            }
        });

        let studioHTML = "";
        selectedPowers.forEach(power => {
            const imgUrl = powers[power];
            if (imgUrl) {
                const imgElement = document.createElement('img');
                imgElement.src = imgUrl;
                imgElement.alt = power;
                imgElement.style.display = 'inline-block'; 
                imgElement.style.margin = '0 10px'; 

               
                const caption = document.createElement('p');
                caption.textContent = power;
                caption.style.color = 'yellow'; 
                caption.style.textAlign = 'center'; 

                
                const container = document.createElement('div');
                container.style.textAlign = 'center'; 
                container.style.display = 'inline-block'; 
                container.style.verticalAlign = 'top'; 
                container.appendChild(imgElement);
                container.appendChild(caption);

                studioHTML += container.outerHTML;

               
                const character = characterPowers[power];
                if (character) {
                  //  studioHTML += `<a href="rank.html?p=${encodeURIComponent(power)}&c=${encodeURIComponent(character)}">${character}</a>`;
                }
            }
        });

        avatarPreview.innerHTML = studioHTML;

        if (selectedPowers.length > 0) {
            alert('Powers selected: ' + selectedPowers.join(', '));
        } else {
            alert('Please select at least one power.');
        }

        
        localStorage.setItem('selectedPowers', JSON.stringify(selectedPowers));
    }

    createAvatarBtn.addEventListener("click", createAvatar);

    
    const storedPowers = JSON.parse(localStorage.getItem('selectedPowers'));
    if (storedPowers && storedPowers.length > 0) {
        // Envia os poderes para a página de ranking
        //window.location.href = 'rank.html?p=' + encodeURIComponent(JSON.stringify(storedPowers));
    }
});
